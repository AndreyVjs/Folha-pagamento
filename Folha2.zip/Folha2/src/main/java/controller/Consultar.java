package controller;

import model.funcModel;
import service.FuncionarioService;
import java.util.List;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

import java.awt.BorderLayout; // Necessário para o layout
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * Tela de consulta de funcionários.
 */
public class Consultar extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Consultar.class.getName());

    // VARIÁVEIS DE COMPONENTES
    private JTable tabelaFuncionarios;
    private JButton jButtonVoltar;


    /**
     * Cria uma nova tela de Consultar.
     */
    public Consultar() {
        // Inicializa e posiciona os componentes
        initComponents();
        // Carrega os dados do banco de dados na tabela ao iniciar a tela
        carregarTabelaFuncionarios();
    }

    // =======================================================================
    // MÉTODO: TRATAMENTO DO BOTÃO VOLTAR
    // =======================================================================
    /**
     * Ação executada ao clicar no botão "Voltar". Fecha a janela atual.
     */
    private void jButtonVoltarActionPerformed(java.awt.event.ActionEvent evt) {
        new menuAdmin().setVisible(true);
        this.dispose();

        // Se houver uma tela de menu principal (ex: MenuAdmin),
        // você a chamaria aqui:
        // new MenuAdmin().setVisible(true);
    }

    // =======================================================================
    // MÉTODO: LÓGICA DE CARREGAMENTO DE DADOS NA TABELA
    // =======================================================================
    private void carregarTabelaFuncionarios() {
        try {
            // Chamada à camada Service para obter a lista
            FuncionarioService service = new FuncionarioService();
            List<funcModel> lista = service.consultarTodos();

            // Define o cabeçalho da tabela
            String[] colunas = {"Nome", "Usuário", "Salário Base (R$)", "Custo Total (R$)"};

            // Cria o modelo de tabela e desabilita a edição das células
            DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            // Preenche o modelo com os dados
            for (funcModel f : lista) {
                modeloTabela.addRow(new Object[]{
                        f.getNome(),
                        f.getUsuario(),
                        f.getSalarioBase(),
                        f.getCustoEfetivoTotal()
                });
            }

            // Aplica o modelo à JTable
            tabelaFuncionarios.setModel(modeloTabela);

            // Ajustar larguras das colunas (melhora a visualização)
            if (lista.size() > 0) {
                tabelaFuncionarios.getColumnModel().getColumn(0).setPreferredWidth(150);
                tabelaFuncionarios.getColumnModel().getColumn(3).setPreferredWidth(120);
            }

            logger.log(Level.INFO, "{0} funcionários carregados na tabela.", lista.size());

        } catch (Exception e) {
            logger.log(Level.SEVERE, "Erro ao carregar a tabela de funcionários.", e);
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar dados. Verifique a conexão com o banco de dados.",
                    "Erro de Consulta", JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * Inicializa e configura todos os componentes visuais da tela.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        // 1. Inicialização dos componentes
        tabelaFuncionarios = new JTable();
        JScrollPane scrollPane = new JScrollPane(tabelaFuncionarios);
        jButtonVoltar = new JButton("Voltar");
        JPanel panelBotoes = new JPanel(); // Usa FlowLayout por padrão

        // 2. Configuração do Painel de Botões
        panelBotoes.add(jButtonVoltar);

        // 3. Ação do Botão Voltar
        jButtonVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVoltarActionPerformed(evt);
            }
        });

        // 4. Configuração da Janela
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Consulta de Funcionários Cadastrados");

        // 5. Configuração do Layout: Usamos BorderLayout
        getContentPane().setLayout(new BorderLayout());

        // 6. Adiciona a JTable no CENTRO (Ocupa a maior parte)
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // 7. Adiciona o painel de botões no SUL (Parte inferior)
        getContentPane().add(panelBotoes, BorderLayout.SOUTH);


        // Define o tamanho da janela e a centraliza
        setSize(600, 450);
        setLocationRelativeTo(null);
    }// </editor-fold>

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Consultar().setVisible(true));
    }
}