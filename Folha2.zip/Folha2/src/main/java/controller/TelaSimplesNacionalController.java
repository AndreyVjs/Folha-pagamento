package controller;

import model.calculoModel;
import service.FuncionarioService;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public class TelaSimplesNacionalController {

    private final FuncionarioService service = new FuncionarioService();
    private final DecimalFormat df = new DecimalFormat("R$ #,##0.00");

    /**
     * Busca os dados do cálculo e abre a tela solicitada.
     * @param nomeFunc Nome do funcionário
     * @param telaDesejada 1 = Tela 1 / 2 = Tela 2 / 3 = Tela 3
     */
    public void exibirCalculos(String nomeFunc, int telaDesejada) {

        calculoModel resultado = service.buscarCalculoSimples(nomeFunc);

        if (resultado == null) {
            System.out.println("Cálculo Simples Nacional não encontrado para o funcionário: " + nomeFunc);
            return;
        }

        // Instancia as telas
        Simples_nacional_1 tela1 = new Simples_nacional_1();
        Simples_nacional_2 tela2 = new Simples_nacional_2();
        Simples_nacional_3 tela3 = new Simples_nacional_3();

        // Preenche as telas
        preencherTela1(tela1, resultado);
        preencherTela2(tela2, resultado);
        preencherTela3(tela3, resultado);

        // Decide qual tela abrir
        switch (telaDesejada) {
            case 1 -> tela1.setVisible(true);
            case 2 -> tela2.setVisible(true);
            case 3 -> tela3.setVisible(true);
            default -> System.out.println("Número da tela inválido: " + telaDesejada);
        }
    }

    // --------- MÉTODOS DE PREENCHIMENTO ---------

    private void preencherTela1(Simples_nacional_1 tela, calculoModel resultado) {
        tela.getFgts_salario().setText(formatar(resultado.getFgts_salario()));
        tela.getSubtotal().setText(formatar(resultado.getSubtotal()));
        tela.getAuxilio_refeicao().setText(formatar(resultado.getAuxilioRefeicao()));
        tela.getAuxilio_alimentacao1().setText(formatar(resultado.getAuxilioAlimentacao()));
        tela.getPlano_saude1().setText(formatar(resultado.getPlanoSaude()));
        tela.getOutros_beneficios1().setText(formatar(resultado.getOutrosBeneficios()));
    }

    private void preencherTela2(Simples_nacional_2 tela, calculoModel resultado) {
        tela.getFerias_proporcionais().setText(formatar(resultado.getFerias_prporcionais()));
        tela.getAdicional_ferias().setText(formatar(resultado.getAdicional_ferias()));
        tela.getFgts_ferias_adicional().setText(formatar(resultado.getFgts_ferias_adicional()));
        tela.getDecimo_terceiro().setText(formatar(resultado.getDecimo_terceiro()));
        tela.getFgts_decimo_terceiro().setText(formatar(resultado.getFgts_decimo_terceiro()));
    }

    private void preencherTela3(Simples_nacional_3 tela, calculoModel resultado) {
        tela.getAviso_previo().setText(formatar(resultado.getAviso_previo()));
        tela.getFgts_aviso_previo().setText(formatar(resultado.getFgts_aviso_previo()));
        tela.getMulta_fgts().setText(formatar(resultado.getMulta_fgts()));
        tela.getSubtotal_provisionado().setText(formatar(resultado.getSubtotal_previsionado()));
    }

    // ---- Formatação de valores ----
    private String formatar(BigDecimal valor) {
        return valor != null ? df.format(valor) : df.format(BigDecimal.ZERO);
    }
}
