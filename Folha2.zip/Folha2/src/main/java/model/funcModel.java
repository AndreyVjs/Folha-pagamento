package model;

import java.math.BigDecimal;

/**
 * Classe Model que representa a entidade Funcionario no sistema.
 * Contém dados de login (nome, usuario, senha, nivelAcesso) e dados financeiros (salarios e beneficios).
 */
public class funcModel {

    // Dados de Login e Identificação
    private Integer id;
    private String nome;
    private String usuario;
    private String senha; // Em um sistema real, use hash para a senha!
    private String nivelAcesso; // Adicionado: Corresponde a 'nivel_acesso' no DB

    // Dados Financeiros (usando BigDecimal para precisão monetária)
    private BigDecimal salarioBase;
    private BigDecimal auxilioRefeicao;
    private BigDecimal auxilioAlimentacao;
    private BigDecimal planoSaude;
    private BigDecimal outrosBeneficios;
    private BigDecimal custoEfetivoTotal; // Será calculado pelo Service

    // -------------------------------------------------------------------------
    // CONSTRUTOR COMPLETO DE 9 ARGUMENTOS (Para uso em formulários)
    // -------------------------------------------------------------------------
    public funcModel(String nome, String usuario, String senha, BigDecimal salarioBase, 
                     BigDecimal auxilioRefeicao, BigDecimal auxilioAlimentacao, 
                     BigDecimal planoSaude, BigDecimal outrosBeneficios, String nivelAcesso) {
         
        this.nome = nome;
        this.usuario = usuario;
        this.senha = senha;
        this.nivelAcesso = nivelAcesso;
        this.salarioBase = salarioBase;
        this.auxilioRefeicao = auxilioRefeicao;
        this.auxilioAlimentacao = auxilioAlimentacao;
        this.planoSaude = planoSaude;
        this.outrosBeneficios = outrosBeneficios;
        this.custoEfetivoTotal = BigDecimal.ZERO; // Inicializado como 0, o Service irá calcular.
    }

    // Construtor Vazio (pode ser útil para frameworks)
    public funcModel() {
    }

    // -------------------------------------------------------------------------
    // GETTERS E SETTERS
    // -------------------------------------------------------------------------

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    
    public String getNivelAcesso() { return nivelAcesso; }
    public void setNivelAcesso(String nivelAcesso) { this.nivelAcesso = nivelAcesso; }

    public BigDecimal getSalarioBase() { return salarioBase; }
    public void setSalarioBase(BigDecimal salarioBase) { this.salarioBase = salarioBase; }

    public BigDecimal getAuxilioRefeicao() { return auxilioRefeicao; }
    public void setAuxilioRefeicao(BigDecimal auxilioRefeicao) { this.auxilioRefeicao = auxilioRefeicao; }

    public BigDecimal getAuxilioAlimentacao() { return auxilioAlimentacao; }
    public void setAuxilioAlimentacao(BigDecimal auxilioAlimentacao) { this.auxilioAlimentacao = auxilioAlimentacao; }

    public BigDecimal getPlanoSaude() { return planoSaude; }
    public void setPlanoSaude(BigDecimal planoSaude) { this.planoSaude = planoSaude; }

    public BigDecimal getOutrosBeneficios() { return outrosBeneficios; }
    public void setOutrosBeneficios(BigDecimal outrosBeneficios) { this.outrosBeneficios = outrosBeneficios; }

    public BigDecimal getCustoEfetivoTotal() { return custoEfetivoTotal; }
    public void setCustoEfetivoTotal(BigDecimal custoEfetivoTotal) { this.custoEfetivoTotal = custoEfetivoTotal; }
}