package model;

import java.math.BigDecimal;

/**
 * Modelo de dados para armazenar os resultados dos cálculos de encargos e os benefícios
 * do funcionário para o regime de cálculo.
 */
public class calculoModel {

    // --- CAMPOS DE BENEFÍCIOS (Trazidos do funcModel para o cálculo) ---
    private BigDecimal auxilioRefeicao;
    private BigDecimal auxilioAlimentacao;
    private BigDecimal planoSaude;
    private BigDecimal outrosBeneficios;


    // --- CAMPOS DE CÁLCULO E ENCARGOS ---
    private BigDecimal Salario_base;
    private BigDecimal Subtotal; // Salário + FGTS Salário
    private BigDecimal Fgts_salario;
    private BigDecimal ferias_prporcionais;
    private BigDecimal Adicional_ferias;
    private BigDecimal Fgts_ferias_adicional;
    private BigDecimal Decimo_terceiro;
    private BigDecimal Fgts_decimo_terceiro;
    private BigDecimal Aviso_previo;
    private BigDecimal Fgts_aviso_previo;
    private BigDecimal Multa_fgts;
    private BigDecimal Subtotal_previsionado; // Somas das provisões mensais (exceto Salário Base)


    // Construtor vazio (recomendado)
    public calculoModel() {
    }

    // --- GETTERS E SETTERS PARA OS BENEFÍCIOS ---

    public BigDecimal getAuxilioRefeicao() {
        return auxilioRefeicao;
    }

    public void setAuxilioRefeicao(BigDecimal auxilioRefeicao) {
        this.auxilioRefeicao = auxilioRefeicao;
    }

    public BigDecimal getAuxilioAlimentacao() {
        return auxilioAlimentacao;
    }

    public void setAuxilioAlimentacao(BigDecimal auxilioAlimentacao) {
        this.auxilioAlimentacao = auxilioAlimentacao;
    }

    public BigDecimal getPlanoSaude() {
        return planoSaude;
    }

    public void setPlanoSaude(BigDecimal planoSaude) {
        this.planoSaude = planoSaude;
    }

    public BigDecimal getOutrosBeneficios() {
        return outrosBeneficios;
    }

    public void setOutrosBeneficios(BigDecimal outrosBeneficios) {
        this.outrosBeneficios = outrosBeneficios;
    }

    // --- GETTERS E SETTERS PARA OS ENCARGOS E TOTAIS ---

    public BigDecimal getSalario_base() {
        return Salario_base;
    }

    public void setSalario_base(BigDecimal Salario_base) {
        this.Salario_base = Salario_base;
    }

    public BigDecimal getSubtotal() {
        return Subtotal;
    }

    public void setSubtotal(BigDecimal Subtotal) {
        this.Subtotal = Subtotal;
    }

    public BigDecimal getFgts_salario() {
        return Fgts_salario;
    }

    public void setFgts_salario(BigDecimal Fgts_salario) {
        this.Fgts_salario = Fgts_salario;
    }

    public BigDecimal getFerias_prporcionais() {
        return ferias_prporcionais;
    }

    public void setFerias_prporcionais(BigDecimal ferias_prporcionais) {
        this.ferias_prporcionais = ferias_prporcionais;
    }

    public BigDecimal getAdicional_ferias() {
        return Adicional_ferias;
    }

    public void setAdicional_ferias(BigDecimal Adicional_ferias) {
        this.Adicional_ferias = Adicional_ferias;
    }

    public BigDecimal getFgts_ferias_adicional() {
        return Fgts_ferias_adicional;
    }

    public void setFgts_ferias_adicional(BigDecimal Fgts_ferias_adicional) {
        this.Fgts_ferias_adicional = Fgts_ferias_adicional;
    }

    public BigDecimal getDecimo_terceiro() {
        return Decimo_terceiro;
    }

    public void setDecimo_terceiro(BigDecimal Decimo_terceiro) {
        this.Decimo_terceiro = Decimo_terceiro;
    }

    public BigDecimal getFgts_decimo_terceiro() {
        return Fgts_decimo_terceiro;
    }

    public void setFgts_decimo_terceiro(BigDecimal Fgts_decimo_terceiro) {
        this.Fgts_decimo_terceiro = Fgts_decimo_terceiro;
    }

    public BigDecimal getAviso_previo() {
        return Aviso_previo;
    }

    public void setAviso_previo(BigDecimal Aviso_previo) {
        this.Aviso_previo = Aviso_previo;
    }

    public BigDecimal getFgts_aviso_previo() {
        return Fgts_aviso_previo;
    }

    public void setFgts_aviso_previo(BigDecimal Fgts_aviso_previo) {
        this.Fgts_aviso_previo = Fgts_aviso_previo;
    }

    public BigDecimal getMulta_fgts() {
        return Multa_fgts;
    }

    public void setMulta_fgts(BigDecimal Multa_fgts) {
        this.Multa_fgts = Multa_fgts;
    }

    public BigDecimal getSubtotal_previsionado() {
        return Subtotal_previsionado;
    }

    public void setSubtotal_previsionado(BigDecimal Subtotal_previsionado) {
        this.Subtotal_previsionado = Subtotal_previsionado;
    }
}