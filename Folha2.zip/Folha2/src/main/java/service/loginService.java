/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import repository.loginRepository;

/**
 *
 * @author train
 */
public class loginService {
    public boolean validarLogin (String Usuario, String Senha, String Nivel_acesso) {

        loginRepository repository = new loginRepository();

        return repository.autenticar(Usuario, Senha, Nivel_acesso);

    }
}
