package service;


import java.math.BigDecimal;
import java.math.RoundingMode;
import model.calculoModel;
import model.funcModel;


/**
 * Classe Service para realizar cálculos de encargos trabalhistas (cálculo anual/previsionado).
 */
public class calculoService {


    private static final BigDecimal PERCENTUAL_FGTS = new BigDecimal("0.08");
    private static final BigDecimal PERCENTUAL_MULTA_FGTS = new BigDecimal("0.40");
    private static final int ESCALA = 2;
    private static final BigDecimal DOZE_MESES = new BigDecimal("12");


    /**
     * Calcula todos os encargos previstos (FGTS, Férias, 13º, etc.) de um funcionário.
     * @param funcionario O funcModel com o Salário Base preenchido.
     * @return O calculoModel preenchido com todos os valores.
     */
    public calculoModel calcularTodosOsEncargos(funcModel funcionario) {
        calculoModel resultado = new calculoModel();

        BigDecimal salarioBase = funcionario.getSalarioBase() != null 
                                     ? funcionario.getSalarioBase() 
                                     : BigDecimal.ZERO.setScale(ESCALA, RoundingMode.HALF_UP);

        resultado.setSalario_base(salarioBase);

        // 1. FGTS sobre Salário
        BigDecimal fgtsSalario = salarioBase.multiply(PERCENTUAL_FGTS).setScale(ESCALA, RoundingMode.HALF_UP);
        resultado.setFgts_salario(fgtsSalario);
        resultado.setSubtotal(salarioBase.add(fgtsSalario).setScale(ESCALA, RoundingMode.HALF_UP));

        // 2. Férias Proporcionais (Provisão Mensal)
        BigDecimal ferias = salarioBase.divide(DOZE_MESES, ESCALA, RoundingMode.HALF_UP);
        resultado.setFerias_prporcionais(ferias);

        // 3. Adicional de Férias (1/3 sobre as férias)
        BigDecimal adicionalFerias = ferias.divide(new BigDecimal("3"), ESCALA, RoundingMode.HALF_UP);
        resultado.setAdicional_ferias(adicionalFerias);

        // 4. FGTS sobre Férias (Base: Férias + 1/3)
        BigDecimal baseFgtsFerias = ferias.add(adicionalFerias);
        BigDecimal fgtsFeriasAdicional = baseFgtsFerias.multiply(PERCENTUAL_FGTS).setScale(ESCALA, RoundingMode.HALF_UP);
        resultado.setFgts_ferias_adicional(fgtsFeriasAdicional);

        // 5. 13º Salário Proporcional (Provisão Mensal)
        BigDecimal decimoTerceiro = salarioBase.divide(DOZE_MESES, ESCALA, RoundingMode.HALF_UP);
        resultado.setDecimo_terceiro(decimoTerceiro);

        // 6. FGTS sobre 13º Salário
        BigDecimal fgtsDecimoTerceiro = decimoTerceiro.multiply(PERCENTUAL_FGTS).setScale(ESCALA, RoundingMode.HALF_UP);
        resultado.setFgts_decimo_terceiro(fgtsDecimoTerceiro);
        
        // 7. Aviso Prévio Proporcional (Provisão Mensal)
        BigDecimal avisoPrevio = salarioBase.divide(DOZE_MESES, ESCALA, RoundingMode.HALF_UP);
        resultado.setAviso_previo(avisoPrevio);
        
        // 8. FGTS sobre Aviso Prévio
        BigDecimal fgtsAvisoPrevio = avisoPrevio.multiply(PERCENTUAL_FGTS).setScale(ESCALA, RoundingMode.HALF_UP);
        resultado.setFgts_aviso_previo(fgtsAvisoPrevio);
        
        // 9. Multa FGTS (40% sobre o FGTS total provisionado no mês)
        BigDecimal fgtsTotalMensal = fgtsSalario
                .add(fgtsFeriasAdicional)
                .add(fgtsDecimoTerceiro)
                .add(fgtsAvisoPrevio)
                .setScale(ESCALA, RoundingMode.HALF_UP);
                
        BigDecimal multaFgts = fgtsTotalMensal.multiply(PERCENTUAL_MULTA_FGTS).setScale(ESCALA, RoundingMode.HALF_UP);
        resultado.setMulta_fgts(multaFgts);


        // 10. Subtotal Previsionado (Soma de todos os encargos)
        BigDecimal subtotalPrevisionado = fgtsSalario
                .add(ferias)
                .add(adicionalFerias)
                .add(fgtsFeriasAdicional)
                .add(decimoTerceiro)
                .add(fgtsDecimoTerceiro)
                .add(avisoPrevio)
                .add(fgtsAvisoPrevio)
                .add(multaFgts)
                .setScale(ESCALA, RoundingMode.HALF_UP);

        resultado.setSubtotal_previsionado(subtotalPrevisionado);


        return resultado;
    }

}