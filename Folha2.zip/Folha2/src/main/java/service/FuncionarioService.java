package service;


import model.funcModel;
import model.calculoModel; // Necessário para o retorno do cálculo
import repository.FuncionarioRepository;
import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Classe Service para lidar com as regras de negócio de Funcionário.
 */
public class FuncionarioService {

    private FuncionarioRepository repository;
    private static final Logger logger = Logger.getLogger(FuncionarioService.class.getName());


    public FuncionarioService() {
        this.repository = new FuncionarioRepository();
    }

    public boolean cadastrar(funcModel funcionario) throws Exception {
        try {
            BigDecimal cet;
            cet = funcionario.getSalarioBase()
                    .add(funcionario.getAuxilioRefeicao())
                    .add(funcionario.getAuxilioAlimentacao())
                    .add(funcionario.getPlanoSaude())
                    .add(funcionario.getOutrosBeneficios());
            funcionario.setCustoEfetivoTotal(cet);


            return repository.salvar(funcionario);
        } catch (Exception e) {
            System.err.println("ERRO NA CAMADA SERVICE. Mensagem de erro: " + e.getMessage());
            logger.log(Level.SEVERE, "Erro durante o cadastro do funcionário no Service.", e);
            throw e;
        }
    }
    public List<funcModel> consultarTodos() {
        return repository.buscarTodos();
    }


    /**
     * Valida se o nome existe no banco (procura o ID).
     */
    public boolean validarNome(String Nome_func) {
        // Se buscarIdPorNome retornar algo diferente de -1, o nome existe.
        return repository.buscarIdPorNome(Nome_func) != -1;
    }


    public calculoModel calcular(String nomeFunc, String tipoCalculo) {
        // Encontra o ID para usar no método calcular da Repository
        int idFunc = repository.buscarIdPorNome(nomeFunc);

        if (idFunc == -1) {
            logger.log(Level.WARNING, "Funcionário não encontrado pelo nome: " + nomeFunc);
            return null;
        }


        return repository.calcular(idFunc, tipoCalculo);
    }
    
    public calculoModel buscarCalculoSimples(String nomeFunc) {
    int idFunc = repository.buscarIdPorNome(nomeFunc);

    if (idFunc == -1) {
        logger.log(Level.WARNING, "Funcionário não encontrado pelo nome: " + nomeFunc);
        return null;
    }

    // Chama o método que você já tem no Repository
    return repository.buscarCalculoSimplesPorIdFuncionario(idFunc);
}
}