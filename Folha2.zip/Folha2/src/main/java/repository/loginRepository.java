package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
// Importamos a ConnectionFactory que tem as credenciais corretas
// import ConexaoBanco.Conexao; // REMOVIDO PARA USAR ConnectionFactory

public class loginRepository {

    private static final Logger logger = Logger.getLogger(loginRepository.class.getName());

    /**
     * Autentica um usuário no banco de dados com base no nível de acesso.
     * @param Usuario O nome de usuário para autenticar.
     * @param Senha A senha para autenticar.
     * @param Nivel_acesso O nível de acesso (Admin ou Funcionario).
     * @return true se as credenciais forem válidas, false caso contrário.
     */
    public boolean autenticar(String Usuario, String Senha, String Nivel_acesso) {

        String nomeTabela;

        // 1. Determina a tabela correta com base no Nivel_acesso
        if ("Admin".equals(Nivel_acesso)) {
            // Supondo que a tabela de administradores se chame "administrador"
            nomeTabela = "administrador"; 
        } else if ("Funcionario".equals(Nivel_acesso)) {
            // Supondo que a tabela de funcionários se chame "funcionario"
            nomeTabela = "funcionario";
        } else {
            // Nível de acesso inválido
            logger.log(Level.WARNING, "Tentativa de login com Nível de Acesso inválido: " + Nivel_acesso);
            return false;
        }

        // A query foi simplificada, removendo a coluna 'nivel_acesso' do WHERE, 
        // pois a escolha da tabela já garante o nível.
        String sql = "SELECT * FROM " + nomeTabela + " WHERE usuario = ? AND senha = ?";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // ATUALIZAÇÃO: Usando a ConnectionFactory centralizada e corrigida
            conn = ConnectionFactory.getConnection(); 
            stmt = conn.prepareStatement(sql);

            stmt.setString(1, Usuario);
            stmt.setString(2, Senha);
            // O Nivel_acesso não é mais necessário no WHERE se a tabela já o define.

            rs = stmt.executeQuery();
            
            // Log para debug
            if (!rs.next()) {
                logger.log(Level.INFO, "Autenticação falhou para usuário: {0} na tabela: {1}", new Object[]{Usuario, nomeTabela});
                return false;
            }

            return true; // Retorna true se encontrar o registro
            
        } catch (SQLException e) {
            // Log detalhado em caso de erro de conexão ou SQL
            logger.log(Level.SEVERE, "Erro fatal de SQL/Conexão ao autenticar.", e);
            System.err.println("------------------------------------------------------------------");
            System.err.println("ERRO DE CONEXÃO/SQL NO LOGIN: " + e.getMessage());
            System.err.println("------------------------------------------------------------------");
            return false;
        } finally {
            // Fechamento seguro dos recursos (rs, stmt, conn)
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Erro ao fechar recursos de conexão no login.", e);
            }
        }
    }
}