// Conteúdo FINAL do arquivo: repository/ConnectionFactory.java

package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionFactory {
    
    private static final Logger logger = Logger.getLogger(ConnectionFactory.class.getName());
    
    // =========================================================================
    // *** CONFIGURAÇÕES CORRETAS (CONFIRMADAS) ***
    // =========================================================================
    private static final String URL = "jdbc:mysql://localhost:3306/Folha_pagamento";
    private static final String USER = "root"; 
    private static final String PASSWORD = "162534andrey.";
    // =========================================================================

    /**
     * Estabelece e retorna a conexão com o banco de dados.
     */
    public static Connection getConnection() throws SQLException {
        try {
            // Garante que o driver está carregado
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Tenta estabelecer a conexão
            return DriverManager.getConnection(URL, USER, PASSWORD);
            
        } catch (ClassNotFoundException e) {
            // Este erro significa que o JAR do MySQL não está no projeto
            logger.log(Level.SEVERE, "Driver JDBC do MySQL não encontrado. Verifique as bibliotecas (Libraries).", e);
            throw new SQLException("Erro ao carregar o driver do banco de dados.", e);
        } 
        // Se houver falha de credencial/servidor, uma SQLException será lançada aqui.
    }
}