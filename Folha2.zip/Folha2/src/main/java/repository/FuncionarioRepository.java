package repository;


import model.funcModel;
import model.calculoModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import service.calculoService;
import java.math.BigDecimal;
import repository.ConnectionFactory;


public class FuncionarioRepository {

    private static final Logger logger = Logger.getLogger(FuncionarioRepository.class.getName());


    public boolean salvar(funcModel funcionario) {
        String sql = "INSERT INTO Funcionario (nome, usuario, senha, nivel_acesso, salario_base, " +
                     "auxilio_refeicao, auxilio_alimentacao, plano_saude, outros_beneficios, custo_efetivo_total) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, funcionario.getNome());
            stmt.setString(2, funcionario.getUsuario());
            stmt.setString(3, funcionario.getSenha());
            stmt.setString(4, funcionario.getNivelAcesso() != null ? funcionario.getNivelAcesso() : "Funcionario");
            stmt.setBigDecimal(5, funcionario.getSalarioBase());
            stmt.setBigDecimal(6, funcionario.getAuxilioRefeicao());
            stmt.setBigDecimal(7, funcionario.getAuxilioAlimentacao());
            stmt.setBigDecimal(8, funcionario.getPlanoSaude());
            stmt.setBigDecimal(9, funcionario.getOutrosBeneficios());
            stmt.setBigDecimal(10, funcionario.getCustoEfetivoTotal());

            return stmt.executeUpdate() > 0;


        } catch (SQLException e) {
            logger.log(Level.SEVERE, "ERRO REAL DO SQL/CONEXÃO ao salvar funcModel: " + e.getMessage(), e);
            if (e.getErrorCode() == 1062) { return false; } 
            return false;
        } finally {
            fecharRecursos(stmt, conn);
        }
    }


    public List<funcModel> buscarTodos() {
        List<funcModel> listaFuncionarios = new ArrayList<>();
        String sql = "SELECT * FROM Funcionario ORDER BY nome";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                funcModel funcionario = new funcModel(
                    rs.getString("nome"),
                    rs.getString("usuario"),
                    rs.getString("senha"),
                    rs.getBigDecimal("salario_base"),
                    rs.getBigDecimal("auxilio_refeicao"),
                    rs.getBigDecimal("auxilio_alimentacao"),
                    rs.getBigDecimal("plano_saude"),
                    rs.getBigDecimal("outros_beneficios"),
                    rs.getString("nivel_acesso")
                );
                funcionario.setCustoEfetivoTotal(rs.getBigDecimal("custo_efetivo_total"));
                funcionario.setId(rs.getInt("id"));
                listaFuncionarios.add(funcionario);
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Erro ao buscar todos os funcionários.", e);
        } finally {
            fecharRecursos(rs, stmt, conn);
        }
        return listaFuncionarios;
    }

    public int buscarIdPorNome(String nome) {
        String sql = "SELECT id FROM Funcionario WHERE nome = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nome);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Erro ao buscar ID por nome.", e);
        } finally {
            fecharRecursos(rs, stmt, conn);
        }
        return -1;
    }


    public funcModel buscarPorId(int id) {
        String sql = "SELECT * FROM Funcionario WHERE id = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        funcModel funcionario = null;

        try {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                funcionario = new funcModel(
                    rs.getString("nome"),
                    rs.getString("usuario"),
                    rs.getString("senha"),
                    rs.getBigDecimal("salario_base"),
                    rs.getBigDecimal("auxilio_refeicao"),
                    rs.getBigDecimal("auxilio_alimentacao"),
                    rs.getBigDecimal("plano_saude"),
                    rs.getBigDecimal("outros_beneficios"),
                    rs.getString("nivel_acesso")
                );
                funcionario.setCustoEfetivoTotal(rs.getBigDecimal("custo_efetivo_total"));
                funcionario.setId(rs.getInt("id"));
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Erro ao buscar funcionário por ID.", e);
        } finally {
            fecharRecursos(rs, stmt, conn);
        }
        return funcionario;
    }


    public boolean salvarCalculoSimples(int idFuncionario, calculoModel resultado, funcModel x) {

        String sql = "INSERT INTO Simples_Nacional (funcionario_id, auxilio_refeicao, auxilio_alimentacao, plano_saude, outros_beneficios, salario_base, subtotal, fgts_salario, " +
                     "ferias_prporcionais, adicional_ferias, fgts_ferias_adicional, decimo_terceiro, " +
                     "fgts_decimo_terceiro, aviso_previo, fgts_aviso_previo, multa_fgts, subtotal_previsionado) " +
                     "VALUES (?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?) " +
                     "ON DUPLICATE KEY UPDATE " +
                     "auxilio_refeicao=?, auxilio_alimentacao=?, plano_saude=?, outros_beneficios=?, salario_base=?, subtotal=?, fgts_salario=?, " +
                     "ferias_prporcionais=?, adicional_ferias=?, fgts_ferias_adicional=?, decimo_terceiro=?, " +
                     "fgts_decimo_terceiro=?, aviso_previo=?, fgts_aviso_previo=?, multa_fgts=?, subtotal_previsionado=?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);

            int i = 1;
            stmt.setInt(i++, idFuncionario);

            // VALORES DO INSERT (PARÂMETROS 2 a 18)
            stmt.setBigDecimal(i++, x.getAuxilioRefeicao());
            stmt.setBigDecimal(i++, x.getAuxilioAlimentacao());
            stmt.setBigDecimal(i++, x.getPlanoSaude());
            stmt.setBigDecimal(i++, x.getOutrosBeneficios());

            stmt.setBigDecimal(i++, resultado.getSalario_base());
            stmt.setBigDecimal(i++, resultado.getSubtotal());
            stmt.setBigDecimal(i++, resultado.getFgts_salario());
            stmt.setBigDecimal(i++, resultado.getFerias_prporcionais());
            stmt.setBigDecimal(i++, resultado.getAdicional_ferias());
            stmt.setBigDecimal(i++, resultado.getFgts_ferias_adicional());
            stmt.setBigDecimal(i++, resultado.getDecimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getFgts_decimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getAviso_previo());
            stmt.setBigDecimal(i++, resultado.getFgts_aviso_previo());
            stmt.setBigDecimal(i++, resultado.getMulta_fgts());
            stmt.setBigDecimal(i++, resultado.getSubtotal_previsionado());

            // VALORES DO ON DUPLICATE KEY UPDATE (PARÂMETROS 19 a 34)
            // Aqui é onde o erro estava, a ordem do UPDATE tem que casar com o SQL
            stmt.setBigDecimal(i++, x.getAuxilioRefeicao());
            stmt.setBigDecimal(i++, x.getAuxilioAlimentacao());
            stmt.setBigDecimal(i++, x.getPlanoSaude());
            stmt.setBigDecimal(i++, x.getOutrosBeneficios());

            stmt.setBigDecimal(i++, resultado.getSalario_base());
            stmt.setBigDecimal(i++, resultado.getSubtotal());
            stmt.setBigDecimal(i++, resultado.getFgts_salario());
            stmt.setBigDecimal(i++, resultado.getFerias_prporcionais());
            stmt.setBigDecimal(i++, resultado.getAdicional_ferias());
            stmt.setBigDecimal(i++, resultado.getFgts_ferias_adicional());
            stmt.setBigDecimal(i++, resultado.getDecimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getFgts_decimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getAviso_previo());
            stmt.setBigDecimal(i++, resultado.getFgts_aviso_previo());
            stmt.setBigDecimal(i++, resultado.getMulta_fgts());
            stmt.setBigDecimal(i++, resultado.getSubtotal_previsionado());


            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "ERRO ao salvar/atualizar Simples Nacional: " + e.getMessage(), e);
            return false;
        } finally {
            fecharRecursos(stmt, conn);
        }
    }


    public boolean salvarCalculoNaoOptante(int idFuncionario, calculoModel resultado) {

        String sql = "INSERT INTO Nao_Optante_Simples_Nacional (funcionario_id, salario_base, subtotal, fgts_salario, " +
                     "ferias_prporcionais, adicional_ferias, fgts_ferias_adicional, decimo_terceiro, " +
                     "fgts_decimo_terceiro, aviso_previo, fgts_aviso_previo, multa_fgts, subtotal_previsionado) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE " +
                     "salario_base=?, subtotal=?, fgts_salario=?, ferias_prporcionais=?, adicional_ferias=?, fgts_ferias_adicional=?, " +
                     "decimo_terceiro=?, fgts_decimo_terceiro=?, aviso_previo=?, fgts_aviso_previo=?, multa_fgts=?, subtotal_previsionado=?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);

            int i = 1;
            stmt.setInt(i++, idFuncionario);

            // VALORES DO INSERT
            stmt.setBigDecimal(i++, resultado.getSalario_base());
            stmt.setBigDecimal(i++, resultado.getSubtotal());
            stmt.setBigDecimal(i++, resultado.getFgts_salario());
            stmt.setBigDecimal(i++, resultado.getFerias_prporcionais());
            stmt.setBigDecimal(i++, resultado.getAdicional_ferias());
            stmt.setBigDecimal(i++, resultado.getFgts_ferias_adicional());
            stmt.setBigDecimal(i++, resultado.getDecimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getFgts_decimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getAviso_previo());
            stmt.setBigDecimal(i++, resultado.getFgts_aviso_previo());
            stmt.setBigDecimal(i++, resultado.getMulta_fgts());
            stmt.setBigDecimal(i++, resultado.getSubtotal_previsionado());

            // VALORES DO ON DUPLICATE KEY UPDATE
            stmt.setBigDecimal(i++, resultado.getSalario_base());
            stmt.setBigDecimal(i++, resultado.getSubtotal());
            stmt.setBigDecimal(i++, resultado.getFgts_salario());
            stmt.setBigDecimal(i++, resultado.getFerias_prporcionais());
            stmt.setBigDecimal(i++, resultado.getAdicional_ferias());
            stmt.setBigDecimal(i++, resultado.getFgts_ferias_adicional());
            stmt.setBigDecimal(i++, resultado.getDecimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getFgts_decimo_terceiro());
            stmt.setBigDecimal(i++, resultado.getAviso_previo());
            stmt.setBigDecimal(i++, resultado.getFgts_aviso_previo());
            stmt.setBigDecimal(i++, resultado.getMulta_fgts());
            stmt.setBigDecimal(i++, resultado.getSubtotal_previsionado());


            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "ERRO ao salvar/atualizar Não Optante Sim: " + e.getMessage(), e);
            return false;
        } finally {
            fecharRecursos(stmt, conn);
        }
    }

    public calculoModel calcular(int id, String tipoCalculo) {
        funcModel funcionario = buscarPorId(id);

        if (funcionario == null) {
            logger.log(Level.WARNING, "Funcionário com ID " + id + " não encontrado para cálculo.");
            return null;
        }
       calculoService calculoService = new calculoService();

        calculoModel resultadoCalculo = calculoService.calcularTodosOsEncargos(funcionario);


        boolean salvo = false;
        if ("Simples nacional".equals(tipoCalculo)) {
            salvo = salvarCalculoSimples(id, resultadoCalculo, funcionario); 
        } else if ("Não optante sim".equals(tipoCalculo)) {
            salvo = salvarCalculoNaoOptante(id, resultadoCalculo);
        }

        if (salvo) {
            return resultadoCalculo;
        } else {
            logger.log(Level.SEVERE, "Falha ao salvar o resultado do cálculo para o regime: " + tipoCalculo);
            return null;
        }
    }


    private Connection obterConexao() throws SQLException {
        return ConnectionFactory.getConnection();
    }


    private void fecharRecursos(PreparedStatement stmt, Connection conn) {
        fecharRecursos(null, stmt, conn);
    }


    private void fecharRecursos(ResultSet rs, PreparedStatement stmt, Connection conn) {
        try {
            if (rs != null) { rs.close(); }
            if (stmt != null) { stmt.close(); }
            if (conn != null) { conn.close(); }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Erro ao fechar recursos de conexão.", e);
        }
    }
    
    // Dentro de public class FuncionarioRepository { ...

    /**
     * Busca o cálculo Simples Nacional e os benefícios salvos por ID de funcionário.
     * @param idFuncionario ID do funcionário
     * @return calculoModel populado com encargos e benefícios do Simples Nacional ou null.
     */
    public calculoModel buscarCalculoSimplesPorIdFuncionario(int idFuncionario) {
        // Seleciona todos os campos necessários
        String sql = "SELECT auxilio_refeicao, auxilio_alimentacao, plano_saude, outros_beneficios, " +
                     "salario_base, subtotal, fgts_salario, ferias_prporcionais, adicional_ferias, " +
                     "fgts_ferias_adicional, decimo_terceiro, fgts_decimo_terceiro, aviso_previo, " +
                     "fgts_aviso_previo, multa_fgts, subtotal_previsionado " +
                     "FROM Simples_Nacional WHERE funcionario_id = ?";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        calculoModel resultado = null;

        try {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idFuncionario);
            rs = stmt.executeQuery();

            if (rs.next()) {
                resultado = new calculoModel();
                
                // --- 1. POPULA OS BENEFÍCIOS (CAMPOS DO funcModel SALVOS) ---
                // NOTE: Seu calculoModel precisa dos setters para estes campos.
                resultado.setAuxilioRefeicao(rs.getBigDecimal("auxilio_refeicao"));
                resultado.setAuxilioAlimentacao(rs.getBigDecimal("auxilio_alimentacao"));
                resultado.setPlanoSaude(rs.getBigDecimal("plano_saude"));
                resultado.setOutrosBeneficios(rs.getBigDecimal("outros_beneficios"));
                
                // --- 2. POPULA OS ENCARGOS E TOTAIS (CAMPOS DO calculoModel) ---
                resultado.setSalario_base(rs.getBigDecimal("salario_base"));
                resultado.setSubtotal(rs.getBigDecimal("subtotal"));
                resultado.setFgts_salario(rs.getBigDecimal("fgts_salario"));
                resultado.setFerias_prporcionais(rs.getBigDecimal("ferias_prporcionais"));
                resultado.setAdicional_ferias(rs.getBigDecimal("adicional_ferias"));
                resultado.setFgts_ferias_adicional(rs.getBigDecimal("fgts_ferias_adicional"));
                resultado.setDecimo_terceiro(rs.getBigDecimal("decimo_terceiro"));
                resultado.setFgts_decimo_terceiro(rs.getBigDecimal("fgts_decimo_terceiro"));
                resultado.setAviso_previo(rs.getBigDecimal("aviso_previo"));
                resultado.setFgts_aviso_previo(rs.getBigDecimal("fgts_aviso_previo"));
                resultado.setMulta_fgts(rs.getBigDecimal("multa_fgts"));
                resultado.setSubtotal_previsionado(rs.getBigDecimal("subtotal_previsionado"));
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Erro ao buscar cálculo Simples Nacional por ID de funcionário.", e);
        } finally {
            fecharRecursos(rs, stmt, conn);
        }
        return resultado;
    }

    
}