package com.mycompany.folha2;

// Importe a classe Splash do seu pacote 'controller'
import controller.Splash; 
import javax.swing.SwingUtilities;

/**
 *
 * @author train
 */
public class Folha2 {

    public static void main(String[] args) {
        // Garantir que a inicialização da GUI (JFrame) ocorra na Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            
            // 1. Cria uma instância da sua tela de Splash
            Splash splashScreen = new Splash();
            
            // 2. Torna a tela de Splash visível
            // Como o seu Splash já possui botões "Entrar" e "Sair", 
            // ele funcionará como o ponto de partida da aplicação.
            splashScreen.setVisible(true);
            
            // OBSERVAÇÃO: Não há necessidade de colocar o código principal da aplicação
            // aqui, pois a navegação para a tela de Login será feita 
            // através do botão "Entrar" dentro do seu JFrame Splash.

        });
    }
}